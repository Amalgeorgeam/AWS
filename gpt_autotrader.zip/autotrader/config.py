API_KEY = "your_api_key_here"
CLIENT_ID = "your_client_id_here"
API_SECRET = "your_api_secret_here"
TOTP_SECRET = "your_totp_secret_here"
