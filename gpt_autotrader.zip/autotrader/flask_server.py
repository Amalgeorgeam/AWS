from flask import Flask, request, jsonify, render_template
from SmartApi.smartConnect import SmartConnect
from totp_generator import get_totp
from config import *
from gpt_strategy import analyze_market_input

app = Flask(__name__, template_folder="templates")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        data = request.get_json()
        if not data or "text" not in data:
            return jsonify({"error": "Missing 'text' field"}), 400

        decision = analyze_market_input(data["text"])
        return jsonify(decision)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/place_order", methods=["POST"])
def place_order():
    try:
        data = request.get_json()
        action = data.get("action")
        symbol = data.get("symbol")

        if not action or not symbol:
            return jsonify({"error": "Missing action or symbol"}), 400

        obj = SmartConnect(api_key=API_KEY)
        obj.generateSession(CLIENT_ID, API_SECRET, get_totp())

        # Dummy symbol token for RELIANCE (replace with dynamic lookup if needed)
        token = "2885"

        orderparams = {
            "variety": "NORMAL",
            "tradingsymbol": symbol + "-EQ",
            "symboltoken": token,
            "transactiontype": action.upper(),
            "exchange": "NSE",
            "ordertype": "MARKET",
            "producttype": "INTRADAY",
            "duration": "DAY",
            "price": 0,
            "squareoff": "0",
            "stoploss": "0",
            "quantity": 1
        }

        res = obj.placeOrder(orderparams)
        return jsonify({"message": f"{action} order placed for {symbol}. Order ID: {res}"})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)
