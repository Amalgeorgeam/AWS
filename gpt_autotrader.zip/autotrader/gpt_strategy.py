import openai

openai.api_key = "your-openai-api-key"

def analyze_market_input(human_text: str):
    prompt = f"""You're a stock market expert and trading bot. Analyze the following market update written in natural language.

INPUT:
"""{human_text}"""

Based on this, suggest ONE clear trading decision:
- action: BUY / SELL / HOLD
- symbol: the most relevant stock index or equity (like NIFTY, BANKNIFTY, RELIANCE, etc.)
- reason: short explanation (1 line)

Return strictly in JSON format like:
{{"action": "BUY", "symbol": "RELIANCE", "reason": "Broke resistance at 2500"}}"""

    try:
        res = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        reply = res.choices[0].message.content.strip()
        decision = eval(reply)
        return decision
    except Exception as e:
        print("GPT strategy error:", e)
        return {"action": "HOLD", "symbol": None, "reason": "Error during GPT analysis"}
