import pyotp
from config import TOTP_SECRET

def get_totp():
    return pyotp.TOTP(TOTP_SECRET).now()
