
// content.js - AngelOne Options Assistant
// DISCLAIMER: Educational tool. Trading is risky. You are responsible for all decisions.
// Default mode is DRY RUN (no clicks). Toggle AutoTrade to allow simulated clicks with double-confirm.

(function() {
  const STATE = {
    prices: [],           // sampled raw price points [ {t, ltp} ]
    candles: [],          // 1-min OHLCV built locally
    lastCandleTime: null,
    symbol: null,
    dryRun: true,
    autoTrade: false,
    lastSignal: null,
    recognitionActive: false
  };

  // === UI PANEL ===
  const panel = document.createElement('div');
  panel.id = 'aoa-panel';
  panel.innerHTML = `
    <div class="aoa-header">
      <div class="aoa-title">AngelOne Options Assistant</div>
      <div class="aoa-badges">
        <span id="aoa-dryrun" class="badge on" title="Dry Run: no clicks">DRY RUN</span>
        <span id="aoa-autotrade" class="badge off" title="AutoTrade: try to click Buy/Sell with confirm">AUTO</span>
      </div>
    </div>
    <div class="aoa-body">
      <div class="row">
        <label>Symbol</label>
        <input id="aoa-symbol" placeholder="e.g., NIFTY24NOV 22500CE" />
      </div>
      <div class="row">
        <button id="aoa-listen">🎙️ Listen</button>
        <button id="aoa-suggest">Suggest Now</button>
        <button id="aoa-pick">Pick Price</button>
      </div>
      <div class="row small">Say: "suggest best time and market price for intraday option trading"</div>
      <pre id="aoa-log"></pre>
      <div class="row">
        <button id="aoa-buy" class="primary">Buy (Test)</button>
        <button id="aoa-sell" class="danger">Sell (Test)</button>
      </div>
    </div>
    <div class="aoa-footer">v1.0 · Local TA: EMA9/21, RSI, MACD, ATR, BB</div>
  `;
  document.documentElement.appendChild(panel);

  const logEl = panel.querySelector('#aoa-log');
  function log(msg) {
    const t = new Date().toLocaleTimeString();
    logEl.textContent = `[${t}] ${msg}\n` + logEl.textContent.slice(0, 5000);
  }

  // === SETTINGS TOGGLES ===
  panel.querySelector('#aoa-dryrun').onclick = (e) => {
    STATE.dryRun = !STATE.dryRun;
    e.target.classList.toggle('on', STATE.dryRun);
    e.target.classList.toggle('off', !STATE.dryRun);
    e.target.textContent = STATE.dryRun ? 'DRY RUN' : 'LIVE';
    log(`Dry Run set to ${STATE.dryRun}`);
  };
  panel.querySelector('#aoa-autotrade').onclick = (e) => {
    STATE.autoTrade = !STATE.autoTrade;
    e.target.classList.toggle('on', STATE.autoTrade);
    e.target.classList.toggle('off', !STATE.autoTrade);
    log(`AutoTrade set to ${STATE.autoTrade}`);
  };

  // === SYMBOL INPUT ===
  const symbolInput = panel.querySelector('#aoa-symbol');
  symbolInput.addEventListener('change', () => {
    STATE.symbol = symbolInput.value.trim();
    log(`Symbol set to ${STATE.symbol || '(not set)'}`);
    chrome.storage.sync.set({ 'aoa_symbol': STATE.symbol });
  });
  chrome.storage.sync.get(['aoa_symbol'], (res) => {
    if (res.aoa_symbol) {
      STATE.symbol = res.aoa_symbol;
      symbolInput.value = res.aoa_symbol;
    }
  });

  // === PRICE SCRAPING ===
  function parseNumber(s) {
    if (typeof s !== 'string') return NaN;
    s = s.replace(/[,₹\s]/g, '');
    const m = s.match(/-?\d+(\.\d+)?/);
    return m ? parseFloat(m[0]) : NaN;
  }
  function readPriceHeuristics() {
    // Try common AngelOne page selectors; fallback to scan labels like "LTP"
    const candidates = [];
    const ltpLabel = Array.from(document.querySelectorAll('div,span,td')).find(el => /LTP|Last\s*Price/i.test(el.textContent));
    if (ltpLabel && ltpLabel.parentElement) {
      const nums = ltpLabel.parentElement.innerText.split(/\n|:/).map(parseNumber).filter(x => !Number.isNaN(x));
      if (nums.length) candidates.push(nums[0]);
    }
    // Scan for big numeric spans
    const bigNums = Array.from(document.querySelectorAll('span,div'))
      .map(el => parseNumber(el.textContent))
      .filter(v => !isNaN(v) && v > 0);
    if (bigNums.length) candidates.push(bigNums.sort((a,b)=>b-a)[0]);

    const ltp = candidates.find(v => v > 0);
    return ltp || NaN;
  }

  // Let user pick an element for price
  let priceElement = null;
  function enablePicker() {
    log('Click the element that shows live price. Press ESC to cancel.');
    function onHover(e) { e.target.classList.add('aoa-hover'); }
    function offHover(e) { e.target.classList.remove('aoa-hover'); }
    function onClick(e) {
      e.preventDefault(); e.stopPropagation();
      priceElement = e.target;
      document.removeEventListener('mouseover', onHover);
      document.removeEventListener('mouseout', offHover);
      document.removeEventListener('click', onClick, true);
      document.removeEventListener('keydown', onKey);
      log('Price element selected. I will read its text for LTP.');
    }
    function onKey(e) {
      if (e.key === 'Escape') {
        document.removeEventListener('mouseover', onHover);
        document.removeEventListener('mouseout', offHover);
        document.removeEventListener('click', onClick, true);
        document.removeEventListener('keydown', onKey);
        log('Picker cancelled.');
      }
    }
    document.addEventListener('mouseover', onHover);
    document.addEventListener('mouseout', offHover);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey);
  }

  panel.querySelector('#aoa-pick').onclick = enablePicker;

  function getLTP() {
    let ltp = NaN;
    if (priceElement) {
      ltp = parseNumber(priceElement.textContent);
    }
    if (isNaN(ltp)) ltp = readPriceHeuristics();
    return ltp;
  }

  // === LOCAL BAR BUILDER (1-min) ===
  function onTick() {
    const price = getLTP();
    if (isNaN(price)) return;

    const now = new Date();
    const tsMin = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes(), 0, 0).getTime();

    // raw series
    STATE.prices.push({ t: now.getTime(), ltp: price });
    if (STATE.prices.length > 3000) STATE.prices.shift();

    // build/update candle
    let candle = STATE.candles.length ? STATE.candles[STATE.candles.length -1] : null;
    if (!candle || candle.t !== tsMin) {
      candle = { t: tsMin, o: price, h: price, l: price, c: price, v: 1 };
      STATE.candles.push(candle);
      if (STATE.candles.length > 500) STATE.candles.shift();
    } else {
      candle.h = Math.max(candle.h, price);
      candle.l = Math.min(candle.l, price);
      candle.c = price;
      candle.v += 1;
    }
  }
  setInterval(onTick, 3000); // sample every 3s

  // === TECHNICAL INDICATORS ===
  function ema(values, period) {
    const k = 2/(period+1);
    const out = [];
    let prev = null;
    for (let i=0; i<values.length; i++) {
      const v = values[i];
      prev = prev == null ? v : v*k + prev*(1-k);
      out.push(prev);
    }
    return out;
  }
  function rsi(values, period=14) {
    if (values.length < period+1) return [];
    let gains=0, losses=0;
    for (let i=1;i<=period;i++){
      const diff = values[i]-values[i-1];
      if (diff>=0) gains += diff; else losses -= diff;
    }
    let rs = losses===0 ? 100 : gains/losses;
    const out = [100 - (100/(1+rs))];
    for (let i=period+1;i<values.length;i++){
      const diff = values[i]-values[i-1];
      const gain = Math.max(0, diff), loss = Math.max(0, -diff);
      gains = (gains*(period-1) + gain) / period;
      losses = (losses*(period-1) + loss) / period;
      rs = losses===0 ? 100 : (gains/losses);
      out.push(100 - (100/(1+rs)));
    }
    const pad = new Array(values.length - out.length).fill(null);
    return pad.concat(out);
  }
  function macd(values, fast=12, slow=26, signal=9) {
    const emaFast = ema(values, fast);
    const emaSlow = ema(values, slow);
    const macdLine = emaFast.map((v, i) => v - emaSlow[i]);
    const signalLine = ema(macdLine, signal);
    const hist = macdLine.map((v,i)=> v - signalLine[i]);
    return { macdLine, signalLine, hist };
  }
  function bb(values, period=20, mult=2) {
    if (values.length < period) return { mid: [], upper: [], lower: [] };
    const mid = [];
    for (let i=0;i<values.length;i++){
      const start = Math.max(0, i-period+1);
      const slice = values.slice(start, i+1);
      const avg = slice.reduce((a,b)=>a+b,0)/slice.length;
      const sd = Math.sqrt(slice.reduce((a,b)=>a+(b-avg)*(b-avg),0)/slice.length);
      mid.push(avg);
      (this.upper || (this.upper=[])).push(avg + mult*sd);
      (this.lower || (this.lower=[])).push(avg - mult*sd);
    }
    return { mid, upper: this.upper, lower: this.lower };
  }
  function atr(highs, lows, closes, period=14) {
    const trs = [];
    for (let i=0;i<highs.length;i++){
      const h = highs[i], l = lows[i];
      const pc = i>0 ? closes[i-1] : closes[i];
      trs.push(Math.max(h-l, Math.abs(h-pc), Math.abs(l-pc)));
    }
    // Wilder's smoothing
    let out = [];
    let prev = null;
    trs.forEach((v,i)=>{
      if (i<period) {
        if (prev == null) prev = 0;
        prev += v;
        if (i===period-1) { prev = prev/period; out.push(prev); }
        else out.push(null);
      } else {
        prev = (prev*(period-1) + v)/period;
        out.push(prev);
      }
    });
    return out;
  }

  // === SIGNALS ===
  function computeSuggestion() {
    if (STATE.candles.length < 30) {
      return { status: 'wait', text: 'Collecting data… need ~30 minutes of 1-min candles for reliable TA.' };
    }
    const closes = STATE.candles.map(c=>c.c);
    const highs  = STATE.candles.map(c=>c.h);
    const lows   = STATE.candles.map(c=>c.l);

    const ema9  = ema(closes, 9);
    const ema21 = ema(closes, 21);
    const r14   = rsi(closes, 14);
    const m     = macd(closes);
    const bands = bb(closes, 20, 2);
    const a14   = atr(highs, lows, closes, 14);

    const n = closes.length - 1;
    const trendUp   = ema9[n] > ema21[n];
    const trendDown = ema9[n] < ema21[n];
    const momUp     = m.hist[n] > 0 && m.hist[n] > m.hist[n-1];
    const momDown   = m.hist[n] < 0 && m.hist[n] < m.hist[n-1];
    const volOk     = a14[n] > (0.002 * closes[n]); // ~0.2% ATR
    const rsiBull   = r14[n] != null && r14[n] >= 55 && r14[n] <= 72;
    const rsiBear   = r14[n] != null && r14[n] >= 28 && r14[n] <= 45;
    const nearMid   = Math.abs(closes[n] - bands.mid[n]) < (0.3 * (bands.upper[n]-bands.lower[n]));

    const ltp = getLTP();
    let signal = { side: 'none', reason: 'No setup', price: isNaN(ltp) ? closes[n] : ltp, sl: null, target: null };

    if (trendUp && momUp && volOk && rsiBull && nearMid) {
      signal.side = 'BUY_CE';
      signal.reason = 'Trend up (EMA9>21), MACD rising, ATR ok, RSI mid-high, price near BB mid';
      signal.sl = Math.max(ltp * 0.97, closes[n] - 1.5 * a14[n]);
      signal.target = ltp * 1.02;
    } else if (trendDown && momDown && volOk && rsiBear && nearMid) {
      signal.side = 'BUY_PE';
      signal.reason = 'Trend down (EMA9<21), MACD falling, ATR ok, RSI mid-low, price near BB mid';
      signal.sl = Math.min(ltp * 1.03, closes[n] + 1.5 * a14[n]);
      signal.target = ltp * 0.98;
    }

    const bestTime = (signal.side === 'none') ? 'Wait — no confluence yet. Re-check in 1–3 min.' : 'Now (conditions aligned).';
    const out = {
      status: signal.side === 'none' ? 'wait' : 'action',
      text: `${bestTime}\n${signal.side} @ ~${signal.price.toFixed(2)} | SL: ${signal.sl ? signal.sl.toFixed(2) : '-'} | T1: ${signal.target ? signal.target.toFixed(2) : '-'}\nWhy: ${signal.reason}`
    };
    STATE.lastSignal = signal;
    return out;
  }

  function speak(text) {
    try { chrome.tts.speak(text, { enqueue: false }); } catch(e) {}
  }

  function onSuggest() {
    const s = computeSuggestion();
    log(s.text);
    speak(s.text);
    if (STATE.autoTrade && STATE.lastSignal && STATE.lastSignal.side !== 'none') {
      placeOrderSim(STATE.lastSignal);
    }
  }

  panel.querySelector('#aoa-suggest').onclick = onSuggest;

  // === VOICE TRIGGER ===
  function startListening() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { log('SpeechRecognition not supported in this browser.'); return; }
    if (STATE.recognitionActive) return;

    const rec = new SR();
    rec.lang = 'en-IN';
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    rec.onresult = (e) => {
      const said = e.results[0][0].transcript.toLowerCase();
      log('Heard: ' + said);
      if (said.includes('suggest') && said.includes('best time') && said.includes('market price')) {
        onSuggest();
      } else {
        log('Command not recognized. Say: "suggest best time and market price for intraday option trading"');
      }
    };
    rec.onend = ()=> { STATE.recognitionActive = false; };
    rec.onerror = (e)=> { STATE.recognitionActive = false; log('Voice error: '+ e.error); };

    rec.start();
    STATE.recognitionActive = true;
    log('Listening…');
  }

  panel.querySelector('#aoa-listen').onclick = startListening;

  // === AUTO-CLICK (SAFE: Double confirm + DryRun default) ===
  function findButtonByText(text) {
    const xpath = `//button[normalize-space(translate(., 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'))='${text.toUpperCase()}']`;
    const res = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    if (res.snapshotLength > 0) return res.snapshotItem(0);
    return null;
  }

  function placeOrderSim(signal) {
    const side = signal.side.includes('CE') ? 'BUY' : 'SELL';
    const msg = `${side} ${STATE.symbol || ''} @ ~${signal.price.toFixed(2)}\nSL: ${signal.sl ? signal.sl.toFixed(2) : '-'} | T1: ${signal.target ? signal.target.toFixed(2) : '-'}`;
    if (!confirm('Confirm action:\n' + msg)) return;
    if (!confirm('Final confirmation (trading is risky). Proceed?')) return;

    if (STATE.dryRun) {
      log(`[DRY RUN] Would click ${side}.`);
      return;
    }
    const btn = findButtonByText(side) || findButtonByText(side + ' ORDER') || findButtonByText('BUY') || findButtonByText('SELL');
    if (!btn) { log('Could not find Buy/Sell button on page.'); return; }
    btn.click();
    log(`Clicked ${side}. You may need to confirm order in Angel One UI.`);
  }

  panel.querySelector('#aoa-buy').onclick = ()=> {
    if (!STATE.lastSignal) STATE.lastSignal = { side: 'BUY_CE', price: getLTP(), sl: null, target: null };
    placeOrderSim(STATE.lastSignal);
  };
  panel.querySelector('#aoa-sell').onclick = ()=> {
    if (!STATE.lastSignal) STATE.lastSignal = { side: 'BUY_PE', price: getLTP(), sl: null, target: null };
    placeOrderSim(STATE.lastSignal);
  };

})();
