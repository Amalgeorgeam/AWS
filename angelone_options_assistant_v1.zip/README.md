
# AngelOne Options Assistant (Chrome Extension, MV3)

**Voice-triggered intraday options helper** that runs directly on the Angel One web trading window.
- Say: **“suggest best time and market price for intraday option trading”**
- Computes local **EMA(9/21), RSI(14), MACD(12-26-9), ATR(14), Bollinger Bands(20,2)**
- Suggests **Buy CE / Buy PE** with price, SL and target
- Optional **AutoTrade**: attempts to click **Buy/Sell** buttons on the page (you must double-confirm).  
  _(Default is **DRY RUN**, so it will never click without you turning it off.)_

> **Disclaimer**: For education only. Trading is risky. You are responsible for orders and outcomes.

## Install (Developer Mode)
1. Download the ZIP and extract it.
2. Open `chrome://extensions` → enable **Developer mode**.
3. Click **Load unpacked** → select the extracted folder.
4. Open your Angel One trading page and you should see a floating panel on the top-right.

## Usage
- Type your **Symbol** in the panel (e.g., `NIFTY24NOV 22500CE`), optional but helpful for logs.
- Click **Pick Price** and then click on the page element that shows **live LTP** to lock it in.
- Wait ~30 minutes after market open so the extension can build **1‑minute candles** locally.
- Click **Suggest Now** or press **Listen** and say the voice command.
- Read the suggestion (best time: Now/Wait, market price, SL, target, and the why).
- Toggle **AUTO** if you want it to attempt a click on **Buy/Sell** buttons (still needs double confirmation).
- Toggle **DRY RUN** off if you want real clicks to happen.

## Notes & Limits
- The extension scrapes the current LTP from the page. Use **Pick Price** for robust selection.
- It does **not** use your API credentials or call SmartAPI; it only interacts with the page you’re on.
- UI structures change; the Buy/Sell button finder is heuristic-based. You might need to place the final order in the dialog.
- You can modify the signal logic inside `content.js` → `computeSuggestion()`.

## Safety
- DRY RUN by default.
- Double confirmation prompts before any click.
- No credentials are collected or transmitted.

## Uninstall
Remove from `chrome://extensions`.

— Built for Amal’s intraday options workflow.
