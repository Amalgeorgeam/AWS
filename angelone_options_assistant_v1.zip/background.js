
// background.js (service worker)
// For future: could register alarms to re-run analysis or connect to external data if needed.
chrome.runtime.onInstalled.addListener(() => {
  console.log('AngelOne Options Assistant installed.');
});
