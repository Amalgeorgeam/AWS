
chrome.runtime.onInstalled.addListener(() => { console.log('AOA Local Proxy extension installed'); });
