
AOA Local Proxy — Setup Guide
=============================

This package contains:
- `server/` : Node.js local proxy server (runs on your PC). Endpoints:
   - POST /upload-credentials  -> store Angel One credentials (encrypted on disk)
   - GET  /creds-status        -> check if creds stored
   - POST /analyze            -> analyze snapshot, returns AI result (calls OpenAI if OPENAI_API_KEY present locally)
   - POST /place-order        -> place an order via SmartAPI using stored credentials
- `extension/` : Chrome extension (Manifest V3) that collects LTP/candles and talks to the local proxy at http://localhost:8080

Security notes (READ CAREFULLY):
- The server encrypts stored credentials using AES-256-GCM with `MASTER_KEY` (hex, 32 bytes) from environment variable.
- Set `MASTER_KEY` before starting the server. Example to generate a key:
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
- Set `CLIENT_TOKEN` env variable to a random string and save the same string into the extension token field (used for auth).
- Keep this server only on your local machine (do not expose to the internet) unless you fully understand security.

Quick start:
1. Install Node.js (v16+ recommended).
2. Server:
   - cd server
   - npm ci
   - export MASTER_KEY=<hex32>   (on Windows use set or PowerShell)
   - export CLIENT_TOKEN=<random_token>
   - option: export OPENAI_API_KEY=<your_openai_api_key>  (if you want GPT analysis)
   - node server.js
3. Extension:
   - Load unpacked extension from the `extension` folder in `chrome://extensions`
   - In the panel, paste the CLIENT_TOKEN and click Save Token
   - Use Pick Price, AI Suggest, and Place Order (Place Order will call your local server which will use stored credentials)

Uploading Angel One credentials:
- Use POST /upload-credentials with body `{"angel": {"api_base":"https://YOUR_SMARTAPI_BASE","api_key":"...","client_id":"...","client_secret":"...","session_token":"..."} }`
- Example (curl):
  curl -X POST http://localhost:8080/upload-credentials -H "Content-Type: application/json" -d @creds.json

Notes about SmartAPI:
- SmartAPI endpoints and required fields vary. This server includes a generic /place-order implementation which posts to `{api_base}/order`.
- You must adapt `server.js` order payload and auth headers to match the exact SmartAPI variant you use. See your broker docs.

If you want, I can:
- Adapt /place-order to the exact Angel One SmartAPI flow (I will need the endpoint patterns or docs).
- Build a small CLI tool to upload credentials securely.
- Add additional safety checks (max daily loss, per-order limits) — tell me thresholds.
