
// content.js - Local Proxy variant with Pretty AI Suggest display
(function(){
  const LOCAL_BASE = 'http://localhost:8080';
  const TOKEN_KEY = 'aoa_local_token'; // store the bearer token here (user places CLIENT_TOKEN once)

  // build panel UI
  const panel = document.createElement('div');
  panel.id = 'aoa-panel';
  panel.innerHTML = `
    <div class="aoa-header"><div class="aoa-title">AOA Local Proxy</div>
      <div class="aoa-badges"><span id="aoa-status" class="badge off">NOT AUTH</span></div></div>
    <div class="aoa-body">
      <div class="row"><label>Symbol</label><input id="aoa-symbol" placeholder="e.g., NIFTY24NOV22500CE" /></div>
      <div class="row"><button id="aoa-pick">Pick Price</button><button id="aoa-suggest">AI Suggest (Raw)</button><button id="aoa-suggest-pretty">AI Suggest (Pretty)</button><button id="aoa-place">Place Order</button></div>
      <div class="row small">Set token via Settings → Save Token</div>
      <div class="row"><input id="aoa-token" placeholder="Local CLIENT_TOKEN (for auth)" /><button id="aoa-save-token">Save Token</button></div>
      <div id="aoa-ai-card" style="margin-top:10px; display:none;"></div>
      <pre id="aoa-log"></pre>
    </div>
    <div class="aoa-footer">Local Proxy Mode</div>
  `;
  document.documentElement.appendChild(panel);

  const logEl = panel.querySelector('#aoa-log');
  function log(msg){ const t=new Date().toLocaleTimeString(); logEl.textContent = `[${t}] ${msg}\n` + logEl.textContent.slice(0,4000); }

  // price picker (simplified)
  let priceElement = null;
  function enablePicker() {
    log('Click the element that shows live price. Press ESC to cancel.');
    function onClick(e){ e.preventDefault(); e.stopPropagation(); priceElement = e.target; cleanup(); log('Price element selected.'); }
    function onKey(e){ if(e.key==='Escape') { cleanup(); log('Picker cancelled.'); } }
    function cleanup(){ document.removeEventListener('click', onClick, true); document.removeEventListener('keydown', onKey); document.querySelectorAll('.aoa-hover').forEach(el=>el.classList.remove('aoa-hover')); }
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey);
  }
  panel.querySelector('#aoa-pick').onclick = enablePicker;

  function getLTP() {
    if (priceElement) {
      const txt = priceElement.textContent || priceElement.innerText || '';
      const m = txt.replace(/[,₹\s]/g,'').match(/-?\d+(\.\d+)?/);
      const v = m ? parseFloat(m[0]) : NaN;
      return isNaN(v) ? null : v;
    }
    const nums = Array.from(document.querySelectorAll('span,div')).map(el=>parseFloat((el.textContent||'').replace(/[,₹\s]/g,'').match(/-?\d+(\.\d+)?/)?.[0]||NaN)).filter(n=>!isNaN(n)&&n>0);
    return nums.length ? nums[0] : null;
  }

  // candle builder
  const STATE = { candles: [], lastMinute: null };
  function tick(){
    const ltp = getLTP();
    if (!ltp) return;
    const now = new Date();
    const tsMin = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes(),0,0).getTime();
    let candle = STATE.candles.length ? STATE.candles[STATE.candles.length-1] : null;
    if (!candle || candle.t !== tsMin) {
      candle = { t: tsMin, o: ltp, h: ltp, l: ltp, c: ltp, v:1 };
      STATE.candles.push(candle);
      if (STATE.candles.length>500) STATE.candles.shift();
    } else {
      candle.h = Math.max(candle.h, ltp);
      candle.l = Math.min(candle.l, ltp);
      candle.c = ltp; candle.v += 1;
    }
  }
  setInterval(tick, 3000);

  // token save/load
  const tokenInput = panel.querySelector('#aoa-token');
  panel.querySelector('#aoa-save-token').onclick = ()=> {
    const t = tokenInput.value.trim();
    if (!t) return alert('Enter token');
    chrome.storage.local.set({[TOKEN_KEY]: t}, ()=> { log('Token saved locally (extension storage).'); panel.querySelector('#aoa-status').textContent = 'AUTH'; panel.querySelector('#aoa-status').classList.remove('off'); panel.querySelector('#aoa-status').classList.add('on'); });
  };
  chrome.storage.local.get([TOKEN_KEY], (res)=> { if (res[TOKEN_KEY]) { tokenInput.value = res[TOKEN_KEY]; panel.querySelector('#aoa-status').textContent = 'AUTH'; panel.querySelector('#aoa-status').classList.remove('off'); panel.querySelector('#aoa-status').classList.add('on'); }});

  async function requestAIRaw(){
    const token = await new Promise(r => chrome.storage.local.get([TOKEN_KEY], res => r(res[TOKEN_KEY])));
    if (!token) { alert('Set CLIENT_TOKEN first'); return; }
    const snapshot = { candles: STATE.candles.slice(-60), ltp: getLTP(), symbol: panel.querySelector('#aoa-symbol').value || '' };
    try {
      const resp = await fetch(LOCAL_BASE + '/analyze', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(snapshot)
      });
      const j = await resp.json();
      log('AI result: ' + JSON.stringify(j.ai));
      return j.ai;
    } catch (e) { log('AI request failed: ' + e); return null; }
  }

  panel.querySelector('#aoa-suggest').onclick = requestAIRaw;

  // Pretty AI display
  function renderAICard(ai) {
    const card = panel.querySelector('#aoa-ai-card');
    if (!ai) { card.style.display='none'; return; }
    // ai may be nested under .ai or raw; normalize
    const d = ai.ai ? ai.ai : ai;
    const rec = d.recommendation || d.reco || (d.raw && 'HOLD') || d.recommend || (d.recommendation ? d.recommendation : 'HOLD');
    const entry = d.entry || d.price || (d.raw && null) || d.entry;
    const sl = d.stop_loss || d.sl || d.stoploss || d.stop_loss;
    const target = d.target || d.t1 || d.tp;
    const conf = (d.confidence != null) ? d.confidence : (d.conf ? d.conf : null);
    const reason = d.reason || (d.raw && (typeof d.raw === 'string' ? d.raw : JSON.stringify(d.raw)) ) || '';
    card.style.display='block';
    card.innerHTML = `
      <div style="background:#07101a;border:1px solid #223043;padding:10px;border-radius:8px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="font-weight:700">${rec}</div>
          <div style="font-size:12px;opacity:0.9">Confidence: ${conf != null ? Math.round(conf*100) + '%' : 'N/A'}</div>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px;">
          <div style="flex:1;"><div style="font-size:12px;opacity:0.8">Entry</div><div style="font-weight:600">${entry != null ? entry : '-'}</div></div>
          <div style="flex:1;"><div style="font-size:12px;opacity:0.8">SL</div><div style="font-weight:600">${sl != null ? sl : '-'}</div></div>
          <div style="flex:1;"><div style="font-size:12px;opacity:0.8">Target</div><div style="font-weight:600">${target != null ? target : '-'}</div></div>
        </div>
        <div style="margin-top:8px;font-size:13px;color:#9fb7d6">${reason}</div>
        <div style="margin-top:8px;display:flex;gap:8px;">
          <button id="aoa-ai-act" style="padding:6px 8px;border-radius:6px;background:#1f6feb;border:none;color:white;cursor:pointer;">Act on this</button>
          <button id="aoa-ai-dismiss" style="padding:6px 8px;border-radius:6px;background:#2b2b2b;border:none;color:#e6eef8;cursor:pointer;">Dismiss</button>
        </div>
      </div>
    `;
    // attach listeners
    card.querySelector('#aoa-ai-dismiss').onclick = ()=>{ card.style.display='none'; };
    card.querySelector('#aoa-ai-act').onclick = async ()=>{
      if (!confirm('Confirm: send place-order to local proxy?')) return;
      const token = await new Promise(r => chrome.storage.local.get([TOKEN_KEY], res => r(res[TOKEN_KEY])));
      if (!token) { alert('Set CLIENT_TOKEN first'); return; }
      const side = (rec && rec.toString().toUpperCase().includes('CE')) ? 'BUY' : (rec && rec.toString().toUpperCase().includes('PE') ? 'BUY' : 'BUY');
      const body = { symbol: panel.querySelector('#aoa-symbol').value || '', side, qty: 1, price: entry || 0 };
      try {
        const resp = await fetch(LOCAL_BASE + '/place-order', { method:'POST', headers: { 'Content-Type':'application/json', 'Authorization': 'Bearer '+token }, body: JSON.stringify(body) });
        const j = await resp.json();
        log('Place-order: ' + JSON.stringify(j));
        alert('Place-order response: ' + (j.ok ? 'OK' : JSON.stringify(j)));
      } catch (e) { log('Place-order failed: ' + e); alert('Place-order failed: ' + e); }
    };
  }

  async function requestAIPretty() {
    const ai = await requestAIRaw();
    if (!ai) return;
    // ai may already be structured; pass through
    renderAICard(ai.ai ? ai.ai : ai);
  }

  panel.querySelector('#aoa-suggest-pretty').onclick = requestAIPretty;

  panel.querySelector('#aoa-place').onclick = async ()=>{
    const token = await new Promise(r => chrome.storage.local.get([TOKEN_KEY], res => r(res[TOKEN_KEY])));
    if (!token) { alert('Set CLIENT_TOKEN first'); return; }
    const symbol = panel.querySelector('#aoa-symbol').value || prompt('Symbol?');
    if (!symbol) return;
    const body = { symbol, side: 'BUY', qty: 1 };
    if (!confirm('Place order? This will call local backend to place order.')) return;
    try {
      const resp = await fetch(LOCAL_BASE + '/place-order', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(body) });
      const j = await resp.json();
      log('Place-order response: ' + JSON.stringify(j));
    } catch (e) { log('Place-order failed: ' + e); }
  };

})();
